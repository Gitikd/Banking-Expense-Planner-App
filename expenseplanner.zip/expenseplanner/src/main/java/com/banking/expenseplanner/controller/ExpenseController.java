package com.banking.expenseplanner.controller;

import com.banking.expenseplanner.model.Expense;
import com.banking.expenseplanner.model.User;
import com.banking.expenseplanner.repository.ExpenseRepository;
import com.banking.expenseplanner.repository.UserRepository;
import com.banking.expenseplanner.util.UserUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/expenses")
public class ExpenseController {

    @Autowired
    private ExpenseRepository expenseRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserUtil userUtil;

    // ✅ 1. Create Expense
    @PostMapping("/add")
    public String addExpense(@Valid @RequestBody Expense expense) {
        User user = userUtil.getLoggedInUser();
        expense.setUser(user);
        expenseRepository.save(expense);

        // Update balance based on type
        if ("EXPENSE".equalsIgnoreCase(expense.getType())) {
            user.setBalance(user.getBalance() - expense.getAmount());
        } else if ("INCOME".equalsIgnoreCase(expense.getType())) {
            user.setBalance(user.getBalance() + expense.getAmount());
        }
        userRepository.save(user);

        return "Expense added successfully!";
    }

    // ✅ 2. Get all expenses by logged-in user
    @GetMapping("/my")
    public List<Expense> getExpensesByLoggedUser() {
        User user = userUtil.getLoggedInUser();
        return expenseRepository.findByUser(user);
    }

    // ✅ 3. Update expense
    @PutMapping("/update/{expenseId}")
    public String updateExpense(@PathVariable Long expenseId, @Valid @RequestBody Expense updatedExpense) {
        User loggedUser = userUtil.getLoggedInUser();
        Optional<Expense> existingOpt = expenseRepository.findById(expenseId);

        if (existingOpt.isPresent()) {
            Expense expense = existingOpt.get();

            // Check if the expense belongs to the logged-in user
            if (!expense.getUser().getId().equals(loggedUser.getId())) {
                return "Access denied: You can only update your own expenses.";
            }

            // Optional: Adjust user balance before & after update (advanced)
            expense.setCategory(updatedExpense.getCategory());
            expense.setDescription(updatedExpense.getDescription());
            expense.setAmount(updatedExpense.getAmount());
            expense.setDate(updatedExpense.getDate());
            expense.setType(updatedExpense.getType());
            expense.setNote(updatedExpense.getNote());
            expense.setTags(updatedExpense.getTags());

            expenseRepository.save(expense);
            return "Expense updated successfully!";
        } else {
            return "Expense not found!";
        }
    }

    // ✅ 4. Delete expense
    @DeleteMapping("/delete/{expenseId}")
    public String deleteExpense(@PathVariable Long expenseId) {
        User loggedUser = userUtil.getLoggedInUser();
        Optional<Expense> expenseOpt = expenseRepository.findById(expenseId);

        if (expenseOpt.isPresent()) {
            Expense expense = expenseOpt.get();

            // Check if the expense belongs to the logged-in user
            if (!expense.getUser().getId().equals(loggedUser.getId())) {
                return "Access denied: You can only delete your own expenses.";
            }

            // Reverse the balance effect
            if ("EXPENSE".equalsIgnoreCase(expense.getType())) {
                loggedUser.setBalance(loggedUser.getBalance() + expense.getAmount());
            } else if ("INCOME".equalsIgnoreCase(expense.getType())) {
                loggedUser.setBalance(loggedUser.getBalance() - expense.getAmount());
            }
            userRepository.save(loggedUser);

            expenseRepository.deleteById(expenseId);
            return "Expense deleted successfully!";
        } else {
            return "Expense not found!";
        }
    }
}
