package com.banking.expenseplanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankingExpensePlannerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankingExpensePlannerApplication.class, args);
	}

}
