package com.banking.expenseplanner.controller;

import com.banking.expenseplanner.model.SavingsGoal;
import com.banking.expenseplanner.model.User;
import com.banking.expenseplanner.repository.SavingsGoalRepository;
import com.banking.expenseplanner.util.UserUtil;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/savings")
public class SavingsGoalController {

    @Autowired
    private SavingsGoalRepository savingsGoalRepository;

    @Autowired
    private UserUtil userUtil;

    @PostMapping("/add")
    public ResponseEntity<?> addGoal(@Valid @RequestBody SavingsGoal goal) {
        User user = userUtil.getLoggedInUser();
        goal.setUser(user);
        savingsGoalRepository.save(goal);
        return ResponseEntity.ok("Savings goal created successfully");
    }

    @GetMapping("/my")
    public ResponseEntity<?> getUserGoals() {
        User user = userUtil.getLoggedInUser();
        return ResponseEntity.ok(savingsGoalRepository.findByUser(user));
    }

    @PutMapping("/update/{goalId}")
    public ResponseEntity<?> updateGoalProgress(@PathVariable Long goalId, @RequestParam Double amountToAdd) {
        Optional<SavingsGoal> goalOpt = savingsGoalRepository.findById(goalId);
        if (goalOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("Goal not found");
        }

        SavingsGoal goal = goalOpt.get();
        User user = userUtil.getLoggedInUser();

        if (!goal.getUser().getId().equals(user.getId())) {
            return ResponseEntity.status(403).body("Access denied: This goal does not belong to you.");
        }

        goal.setSavedAmount(goal.getSavedAmount() + amountToAdd);
        if (goal.getSavedAmount() >= goal.getTargetAmount()) {
            goal.setStatus("COMPLETED");
        }
        savingsGoalRepository.save(goal);
        return ResponseEntity.ok("Progress updated");
    }
}