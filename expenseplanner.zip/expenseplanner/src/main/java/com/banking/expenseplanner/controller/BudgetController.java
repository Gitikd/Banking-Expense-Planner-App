package com.banking.expenseplanner.controller;

import com.banking.expenseplanner.model.Budget;
import com.banking.expenseplanner.model.User;
import com.banking.expenseplanner.repository.BudgetRepository;
import com.banking.expenseplanner.util.UserUtil;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/budget")
public class BudgetController {

    @Autowired
    private BudgetRepository budgetRepository;

    @Autowired
    private UserUtil userUtil;

    @PostMapping("/add")
    public ResponseEntity<?> addBudget(@Valid @RequestBody Budget budget) {
        User user = userUtil.getLoggedInUser();
        budget.setUser(user);
        budgetRepository.save(budget);
        return ResponseEntity.ok("Budget added successfully");
    }

    @GetMapping("/my")
    public ResponseEntity<?> getUserBudgets() {
        User user = userUtil.getLoggedInUser();
        return ResponseEntity.ok(budgetRepository.findByUser(user));
    }

    @GetMapping("/my/month/{month}/year/{year}")
    public ResponseEntity<?> getBudgetsForMonth(@PathVariable Integer month, @PathVariable Integer year) {
        User user = userUtil.getLoggedInUser();
        return ResponseEntity.ok(budgetRepository.findByUserAndMonthAndYear(user, month, year));
    }
}