package com.banking.expenseplanner.controller;

import com.banking.expenseplanner.model.Reminder;
import com.banking.expenseplanner.model.User;
import com.banking.expenseplanner.repository.ReminderRepository;
import com.banking.expenseplanner.util.UserUtil;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/reminders")
public class ReminderController {

    @Autowired
    private ReminderRepository reminderRepository;

    @Autowired
    private UserUtil userUtil;

    @PostMapping("/add")
    public ResponseEntity<?> addReminder(@Valid @RequestBody Reminder reminder) {
        User user = userUtil.getLoggedInUser();
        reminder.setUser(user);
        reminderRepository.save(reminder);
        return ResponseEntity.ok("Reminder added successfully");
    }

    @GetMapping("/my")
    public ResponseEntity<?> getRemindersByUser() {
        User user = userUtil.getLoggedInUser();
        return ResponseEntity.ok(reminderRepository.findByUser(user));
    }

    @GetMapping("/upcoming")
    public ResponseEntity<?> getUpcomingReminders() {
        User user = userUtil.getLoggedInUser();
        LocalDate today = LocalDate.now();
        LocalDate nextWeek = today.plusDays(7);
        List<Reminder> reminders = reminderRepository.findByUserAndDueDateBetween(user, today, nextWeek);
        return ResponseEntity.ok(reminders);
    }
}